package com.example.dao_facades
//
//import org.jetbrains.exposed.sql.SizedIterable
//
//interface DAOFacade<T> {
//    fun getOne(): T
//    fun getAll(): List<T>
//    fun insertOne(): T
//    fun updateOne():
//    fun deleteOne()
//}